## Convention: context-data-model-convention.md

### Purpose

Defines the canonical markdown representation of logical, physical, and analytical data models used as context extensions. Provides a standardized structure for documenting schema definitions, entities, attributes, relationships, and supporting objects in a human-readable format. Intended for use as a reference file registered in context.md ## References.

### Applicability

Applies to every data model context extension referenced from .aib_memory/context.md, regardless of domain, technology stack, storage platform, or modelling methodology.

### Normative Language

Keywords MUST, MUST NOT, SHALL, SHOULD, MAY, OPTIONAL per BCP 14 (RFC 2119 + RFC 8174).

### Document Structure

A data model document consists of one or more H2 sections.

Each H2 section represents exactly one data model.

Example:

## Customer Domain

## Product Master

Each H2 heading MUST contain the short business name of the data model.

### Data Model Sections

Each data model MUST contain the following H3 sections:

- Type
- Location
- Description
- Entities

The following H3 sections are OPTIONAL:

- Relations
- Other Objects

No additional H3 sections are permitted.

### Type Section

The Type section defines the modelling abstraction level.

Valid values:

- logical
- physical
- analytical

Exactly one value MUST be specified.

### Location Section

The Location section identifies where the model is physically realized or maintained.

Examples:

- Snowflake database SALES_DB
- SQL Server CustomerDW
- Power BI Semantic Model
- dbt model layer
- N/A - conceptual model only

The value MUST be a single textual description.

### Description Section

The Description section provides a brief summary of the model purpose, scope, and business meaning.

The description SHOULD be concise and implementation-independent.

### Entities Section

The Entities section contains one or more entity definitions.

Each entity MUST be represented by an H4 heading.

Example:

#### Customer

#### Product

Each entity contains an attribute list.

### Entity Attributes

Each attribute MUST be represented as a markdown bullet.

Required fields:

- Name
- Type

Optional fields:

- Physical Name
- Constraints

Example:

- Name: Customer ID
  Type: Integer
  Constraints: Key, Not Null

### Attribute Constraints

Valid constraint types are:

- Key
- Not Null
- Unique
- Foreign Key
- Min Length
- Max Length
- Check

Constraint names MUST match these values exactly.

#### Check Constraint

When using Check, the rule definition MUST be explicitly provided.

Example:

Constraints: Check (Quantity >= 0)

#### Foreign Key Constraint

When using Foreign Key, the referenced entity and attribute SHOULD be specified.

Example:

Constraints: Foreign Key(Customer.Customer ID)

### Relations Section

The Relations section defines relationships between entities.

Each relationship MUST be represented by an H4 heading containing the relationship name.

Example:

#### Customer Orders

Each relationship definition MUST contain:

- Left Side Entity
- Right Side Entity
- Relationship Cardinality

Optional fields:

- Left Side Attribute
- Right Side Attribute

### Relationship Cardinality

Valid cardinality values:

- 1:1
- M:1
- M:M

The convention assumes the Left Side represents the many side when cardinality is M:1.

Example:

- Left Side Entity: Order
- Left Side Attribute: Customer ID
- Right Side Entity: Customer
- Right Side Attribute: Customer ID
- Relationship Cardinality: M:1

### Other Objects Section

The Other Objects section documents model artifacts that are not entities or relationships.

Examples:

- Views
- Measures
- Calculated Columns
- Dataflows
- Stored Procedures
- Functions

Each object MUST be represented by an H4 heading.

Example:

#### Customer Lifetime Value

Each object definition MUST contain:

- Name
- Type
- Description

### Formatting Rules

- UTF-8 Markdown only.
- NO HTML tags.
- NO images.
- NO markdown tables.
- H1 headings are OPTIONAL.
- H2 headings represent data models.
- H3 headings are limited to the defined section names.
- H4 headings are limited to entity names, relationship names, and object names.
- Heading depth MUST NOT exceed H4.
- Attribute definitions MUST use markdown bullet format.
- Entity names MUST be unique within a data model.
- Relationship names MUST be unique within a data model.
- Object names MUST be unique within a data model.

### Quality Gates

A data model document passes validation iff all conditions below are satisfied:

- Every model is represented by an H2 heading.
- Every model contains Type, Location, Description, and Entities sections.
- Type contains exactly one valid value.
- Entities section contains at least one entity.
- Every entity contains at least one attribute.
- Every attribute defines Name and Type.
