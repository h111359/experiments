#!/usr/bin/env python3
"""
move-request-artifacts.py: Move active-request artifacts from .aib_memory/ root
to the active request's subfolder and archive the shared runtime log.
Part of the AIB tool scripts. Invoked by aib-implement.md (pre-close) and
close-request.py (safety net).
Responsibilities: locate the active request folder; move plan-<ID>.md and
analysis-<ID>.md from .aib_memory/ to the request subfolder; rename-to-staging
then binary-append the shared .aib_memory/log.md into
<request-folder>/log_<request_id>.md with fsync-before-cleanup durability.
"""

from __future__ import annotations

import os
import shutil
import stat
import sys
from pathlib import Path

from common import (
    ValidationError,
    artifact_name,
    ensure_workspace,
    parse_args,
    read_input_header,
    slugify,
)

# Artifact types that live at .aib_memory/ root while a request is active.
# The actual filenames are constructed dynamically using artifact_name() so
# that each file carries the request ID, preventing merge conflicts across branches.
_ARTIFACT_TYPES = ("plan", "analysis")

# Fixed filename of the shared active runtime log at .aib_memory/ root.
_ACTIVE_LOG_FILENAME = "log.md"

# Chunk size used for streaming the staged snapshot into the archive.
_ARCHIVE_CHUNK_BYTES = 64 * 1024


class LogArchiveError(ValidationError):
    """Raised when the shared-log archival transaction cannot proceed safely."""


def _require_regular_file(path: Path) -> None:
    """Ensure *path* is a regular non-symlink file or does not exist.

    Args:
        path: Path to verify.

    Raises:
        LogArchiveError: If *path* exists but is a symlink, directory, or other
            special file type.
    """
    if not path.exists() and not path.is_symlink():
        return
    if path.is_symlink():
        raise LogArchiveError(f"log path is a symlink and cannot be archived: {path}")
    st = os.stat(path, follow_symlinks=False)
    if not stat.S_ISREG(st.st_mode):
        raise LogArchiveError(f"log path is not a regular file: {path}")


def _archive_needs_separator(archive_path: Path) -> bool:
    """Return True when the existing archive is non-empty and lacks a trailing newline.

    Args:
        archive_path: Destination archive file path.

    Returns:
        True when a single newline separator must be written before appending
        the next snapshot; False otherwise.
    """
    if not archive_path.exists():
        return False
    size = archive_path.stat().st_size
    if size == 0:
        return False
    with archive_path.open("rb") as fh:
        fh.seek(-1, os.SEEK_END)
        return fh.read(1) != b"\n"


def _append_snapshot(staging_path: Path, archive_path: Path) -> None:
    """Append the staged snapshot to the archive with durability guarantees.

    Streams *staging_path* into *archive_path* in binary mode using a bounded
    chunk buffer, inserts a single newline separator only when both files are
    non-empty and the archive lacks a trailing newline, fsyncs the archive, and
    removes the staging file only after fsync succeeds.

    Args:
        staging_path: Rename-to-staging snapshot of the shared active log.
        archive_path: Destination archive file inside the request subfolder.
    """
    staging_size = staging_path.stat().st_size
    needs_separator = staging_size > 0 and _archive_needs_separator(archive_path)

    archive_path.parent.mkdir(parents=True, exist_ok=True)
    with archive_path.open("ab") as archive_fh:
        if needs_separator:
            archive_fh.write(b"\n")
        with staging_path.open("rb") as staging_fh:
            while True:
                chunk = staging_fh.read(_ARCHIVE_CHUNK_BYTES)
                if not chunk:
                    break
                archive_fh.write(chunk)
        archive_fh.flush()
        os.fsync(archive_fh.fileno())

    # Only remove the staging file after fsync succeeded to preserve
    # at-least-once delivery semantics across crashes.
    staging_path.unlink()


def _archive_shared_log(workspace: Path, request_id: str, dest_folder: Path) -> None:
    """Archive .aib_memory/log.md into <request-folder>/log_<request_id>.md.

    Uses rename-to-staging rollover so the shared log becomes empty immediately
    after the rename and remains available for new writes. Idempotent across
    the pre-close and safety-net invocations: a missing root plus an existing
    archive is a no-op; a leftover staging snapshot from an aborted prior run
    is drained on the next call.

    Args:
        workspace: Resolved workspace root path.
        request_id: Active request identifier.
        dest_folder: Destination request subfolder for the archive.

    Raises:
        LogArchiveError: On unexpected path types or IO failures.
    """
    aib_memory = workspace / ".aib_memory"
    root_log = aib_memory / _ACTIVE_LOG_FILENAME
    staging_log = aib_memory / f"log-staging-{request_id}.md"
    archive_log = dest_folder / f"log_{request_id}.md"

    # Path-type contract: the three managed paths MUST be regular non-symlink
    # files when they exist. Fail closed on unexpected path types.
    _require_regular_file(root_log)
    _require_regular_file(staging_log)
    _require_regular_file(archive_log)

    # Drain any leftover staging snapshot from a prior aborted run first, so
    # ordering is preserved before the current rename-to-staging step.
    if staging_log.exists():
        _append_snapshot(staging_log, archive_log)

    if root_log.exists():
        # Rename-to-staging rollover: makes the active log empty immediately
        # for subsequent writes while the archival transaction proceeds.
        os.replace(root_log, staging_log)
        # Re-create an empty active log so downstream tools observe the
        # shared-log contract without a lazy first-write race.
        root_log.touch()
        _append_snapshot(staging_log, archive_log)
        return

    # Root log absent: ensure the archive exists so consumers see the
    # expected artifact even when no runtime activity was recorded.
    if not archive_log.exists():
        archive_log.parent.mkdir(parents=True, exist_ok=True)
        archive_log.touch()


def move_artifacts(workspace: Path) -> None:
    """Move active-request artifacts and archive the shared log.

    Reads the input.md YAML header to resolve the active request folder and
    request ID. For each artifact type (plan, analysis) moves the ID-suffixed
    file from .aib_memory/ to the request subfolder when present. Archives the
    shared runtime log into <request-folder>/log_<request_id>.md via the
    rename-to-staging transaction described in :func:`_archive_shared_log`.

    Args:
        workspace: Resolved absolute path to the workspace root.

    Raises:
        ValidationError: When the workspace is invalid, the input.md header is
            missing, or no active request is found.
        LogArchiveError: When the shared-log archival transaction fails.
    """
    ensure_workspace(workspace)

    # Read active request state from input.md YAML header.
    header = read_input_header(workspace)
    if header["state"]["status"] == "idle":
        raise ValidationError("No active request found; cannot move artifacts")

    request_id = header["state"]["request_id"].strip()
    title = header["state"]["title"]
    # Derive folder path using the same slugify convention as create-request.py.
    folder_name = f"{request_id}-{slugify(title)}"
    folder_rel = f".aib_memory/requests/{folder_name}"
    dest_folder = workspace / folder_rel
    dest_folder.mkdir(parents=True, exist_ok=True)
    aib_memory = workspace / ".aib_memory"

    # Archive the shared runtime log FIRST so a failure in the fail-closed
    # log-archive transaction aborts before any other artifact is moved.
    _archive_shared_log(workspace, request_id, dest_folder)
    print(
        f"Archived: .aib_memory/{_ACTIVE_LOG_FILENAME} -> "
        f"{(dest_folder / f'log_{request_id}.md').relative_to(workspace)}"
    )

    for artifact_type in _ARTIFACT_TYPES:
        # Construct the ID-suffixed filename (e.g. "plan-R-20260509-2313.md").
        filename = artifact_name(artifact_type, request_id)
        source = aib_memory / filename
        # Archived artifacts keep their ID-suffixed names inside the subfolder.
        dest = dest_folder / filename
        if source.exists():
            # shutil.move handles cross-filesystem moves unlike os.rename
            shutil.move(str(source), str(dest))
            print(f"Moved: {source.relative_to(workspace)} -> {dest.relative_to(workspace)}")
        else:
            print(f"Skipped (not found): .aib_memory/{filename}")


def main() -> None:
    """Entry point: resolve workspace, run move_artifacts, exit cleanly."""
    args = parse_args("Move active-request artifacts to request subfolder")
    workspace = Path(args.workspace).resolve()

    try:
        move_artifacts(workspace)
    except LogArchiveError as exc:
        print(f"ERROR: log-archive: {exc}", file=sys.stderr)
        raise SystemExit(2)
    except ValidationError as exc:
        print(f"ERROR: {exc}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
