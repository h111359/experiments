## Vars
- $RF=request folder
- $IF=.aib_memory/requests/<request-folder>/implementation.md
- $IL=## Implementation Log
- $E=entry block
## Goal
Deterministic, append-only spec for request-scoped implementation log; audit-safe + parser-safe.
## Scope
Applies to each $RF; exactly 1 implementation.md per $RF; request-scoped, append-only.
## Canonical Path
- $IF required.
- File MUST exist after first successful implement action.
## AIB Action Contract (Normative)
- implement MUST write $IF: create missing -> append existing.
- implement MUST preserve append-only history; MUST NOT rewrite/delete prior entries.
- implement MAY synthesize $E content from same-request analysis artifacts.
## Authoring
- Primary author: automation (AIB tools/prompts).
- Human edits allowed only typo fixes or clarifying notes in designated field; structure unchanged.
## File Shape
- Ordered markdown doc:
 - list of .aib_memory/ files considered
 - exactly 1 $IL header
 - chronological $E list, oldest->newest; new $E appended end.
## Entry Format (Strict)
- $E headings/order exact:
 - ### Entry <YYYY-MM-DD HH:MM>
 - #### Scope
 - #### Changes
- Time: local project time, 24h, YYYY-MM-DD HH:MM.
- Heading levels fixed: entry h3; subsections h4.
- Changes section uses markdown bullets (- ).
- Code/cmd/log snippets fenced with triple backticks + lang hint when applicable.
## Field Rules
- Scope: 1-5 sentences; summarize implemented goal; mention impacted areas/components.
- Changes: concrete mods (files/modules/docs/data jobs/infra); bullets SHOULD start past-tense verb.
## Determinism + Append-Only (Normative)
- Append-only: prior entries bit-for-bit unchanged, except authorized typo fixes in Notes (Optional).
- Correction beyond typo -> add new $E; never mutate prior history.
- $E timestamps MUST strictly increase.
- Exactly 1 $E per implement invocation.
- implement spanning multiple commits/steps -> 1 consolidated $E; summarize in Changes.
## Validation (Automation MUST Enforce)
- $IF exists; UTF-8 text.
- Optional prose allowed before $IL; $IL appears exactly once.
- Entry title regex: ^### Entry \d{4}-\d{2}-\d{2} \d{2}:\d{2}$
- Per $E: required subsections exist exactly once, mandated order.
- Timestamps strictly increasing across $E set.
- NO: [markdown tables, external hyperlinks].
## Editing Workflow
- Automation default: append fully formed $E when implement completes.
## Anti-Patterns
- NO: [reorder entries, delete entries, retro-merge multiple implement runs into older $E, base64 screenshot blobs, owner/author/approval metadata in $IF].
- For screenshots/artifacts: store file in repo, reference repo-relative path.
## Product Docs Interaction
- If implementation touches docs artifacts (ex .aib_memory/docs/...): list under Changes + include relative paths under Evidence.
## Tool Consumption Guarantees
- Parsers can rely on: single $IL; entry title regex; fixed subsection sequence; bullet-list Changes structure.
## Size
- Target <=200 lines per $E.
## Security
- Never include secrets/tokens/full credential strings.