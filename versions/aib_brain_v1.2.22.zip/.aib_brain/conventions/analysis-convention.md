# Analysis Document Convention

**Scope:** Normative  
**Applies to:** All files named `analysis-<request_id>.md` generated under `.aib_memory/` (active phase) and archived to `.aib_memory/requests/<request-folder>/` (archived phase).

## 1. Purpose

The **Analysis document** is a **reasoning and knowledge-capture artifact** only. It records the AI's structured thinking about the user request ΓÇö research findings, scope interpretation, domain and technical context, impact awareness, and risk identification.

**The analysis document is NOT an implementation driver.**

- `implement` MUST NOT read the analysis document.
- All implementation-relevant content (assumptions, plan, testing, documentation touchpoints, open questions) is written into `request.md` by the `create-analysis` action.
- Human stakeholders read the analysis for auditability and context; they do not use it as an execution specification.

***

## 2. Scope & Normative Language

This convention applies only to analysis artifacts for a single request:

*   Target files: `analysis.md`
*   Location: `.aib_memory/requests/<request-folder>/`
*   Out of scope: plan, questionnaire, and implementation records (defined by their own conventions or removed)

Normative keywords **MUST**, **MUST NOT**, **SHALL**, **SHOULD**, and **MAY** are interpreted per BCP 14 (RFC 2119 / RFC 8174).

***

## 3. File Naming & Location (Normative)

*   File name **must** follow the pattern: `analysis-<request_id>.md`
    where `<request_id>` is the active request ID (e.g. `analysis-R-20260509-2313.md`).

*   **Two-phase placement rule:**
    1.  **Active phase** — while the request is open, `analysis-<request_id>.md` resides at `.aib_memory/analysis-<request_id>.md` (workspace root of `.aib_memory/`, NOT inside the request subfolder).
    2.  **Archived phase** — upon successful implementation completion, `analysis-<request_id>.md` is moved by `move-request-artifacts.py` to `.aib_memory/requests/<request-folder>/analysis.md` (bare name in the subfolder) before `close-request.py` marks the request Closed.

*   Exactly one analysis file per request **MAY** exist at a time.

*   Re-runs of `aib-analysis.md` **must** fully replace the active copy at `.aib_memory/analysis-<request_id>.md` without merging; re-generation is atomic at the active location.

*   Version metadata (for example: version/author/status headers) **must not** be embedded in the analysis file. Versioning is handled by VCS.

***

## 4. Mandatory Structure

Each analysis file **must** contain the following sections in the exact order:

1. **Executive Summary** **[REQ]**
2. **Files Read During This Analysis Run** **[REQ]**
3. **Research Results** **[REQ]**
4. **Best Practices** **[REQ]**
5. **External Benchmarking** **[REQ]**
6. **Minimal Spikes and Experiments** **[REQ]**
7. **Implementation Alternatives** **[REQ]**
8. **AI Copilot Suggestions** **[REQ]**

***

### 4.1 Executive Summary

A concise overview containing exactly:

- Request ID

- Request title

- High-level purpose

After each bullet keep an empty line for readability.


***

### 4.2 Files Read During This Analysis Run **[REQ]**

List every workspace file read during this analysis run.

- Each entry MUST be a workspace-relative file path.

- Include all files read for preflight, convention loading, and analysis drafting.

- This section MUST NOT be empty.

***

### 4.3 Research Results **[REQ]**

This section lists pattern-based research findings from scanning workspace files and organizational patterns.

- Pattern scan against organizational standards and prior similar solutions.

- Workspace file inspection for impacted components and cross-reference issues.

- Summarize findings and implications; do not embed external links.


## 5. Best Practices **[REQ]**

This section MUST be present and substantive. It documents research-based internet best practices relevant to the request topic.

**Mandatory content:**

- At minimum two findings from industry literature, established frameworks, or open-source communities relevant to the request scope.

- For each finding: a concise statement of the best practice and an applicability assessment for this specific request.

- Explicit rationale for adoption, adaptation, or rejection of each best practice.

**Rules:**

- Summarize findings and implications; do not embed external links.

- Organize as a bulleted list with one sub-bullet per finding.

- MUST NOT be empty or contain only a stub notice.


## 6. External Benchmarking **[REQ]**

This section MUST be present and substantive. It documents research-based context from outside the workspace.

**Mandatory content:**

- Comparable solutions, frameworks, or patterns found in industry literature or open-source ecosystems relevant to the request scope.
- Key takeaways and applicability assessment for each benchmark reference.
- Explicit rationale for adoption, adaptation, or rejection of each benchmarked approach.
- At minimum two external references must be documented per analysis. If no applicable external material exists, explicitly state why and document the absence.

**Rules:**

- Summarize findings and implications; do not embed external links.
- Organize as a bulleted list with one sub-bullet per takeaway.
- MUST NOT be empty or contain only a stub notice.


## 7. Minimal Spikes and Experiments **[REQ]**


This section documents the outcome of brief feasibility experiments or uncertainty-resolution spikes conducted as part of this analysis.

**Mandatory content:**

- For each spike or experiment: a one-sentence hypothesis, the approach taken, the observed outcome, and the conclusion drawn.
- If no spike was conducted: a brief justification explaining why uncertainty was low enough not to require one.

**Format per spike:**

- **Spike: <topic>**
  - Hypothesis: <what was tested>
  - Approach: <how it was tested>
  - Outcome: <what was observed>
  - Conclusion: <what is now known>

**Rules:**

- MUST NOT be empty; use the "no spike needed" form when applicable.
- Each spike MUST be independently reproducible from the described approach.


## 8. Implementation Alternatives **[REQ]**

This section enumerates all implementation approaches that satisfy the request with materially different outcomes. It MUST execute conceptually before Q-block generation.

**Mandatory content:**

- Each approach listed as a named alternative with:

  - A one-sentence description of the approach.

  - Key trade-offs (benefits and drawbacks).

  - Expected impact on the codebase.

- An explicit recommendation stating which alternative is preferred and why.

**Rules:**

- At least one alternative MUST be documented even if only one viable approach exists (document it with the rationale for ruling out others).

- MUST NOT be empty.

- Fully replaced on every analysis re-run.


## 9. AI Copilot Suggestions **[REQ]**

This section is a **reasoning-only artifact**. It provides a sincere, pragmatic, senior-expert-level review of the request from the AI's perspective.

**Purpose:** Surface improvement opportunities, potential pitfalls, and expert observations that a senior developer or solution architect would raise — covering aspects not necessarily visible from the formal request sections alone.

**Mandatory content:**

- At least three distinct observations covering different dimensions (e.g., design quality, implementation risk, missed simplification opportunities, maintainability, testability, or scope creep risk).
- For each observation: a concise statement of the finding and a concrete actionable suggestion.
- An explicit note if the scope appears larger or smaller than necessary to achieve the stated goal.

**Tone and format:**

- Written as a senior expert speaking directly to the developer — direct, honest, and constructive.
- Organized as a bulleted list; one sub-bullet per actionable suggestion.
- MUST NOT contain implementation steps, code snippets, or prescriptive instructions that could serve as a specification for `implement`.
- MUST NOT be empty.

**Restriction:** This section is a reasoning artifact only. `implement` MUST NOT read or act on this section. It is for human review and auditability only.


## 10. Maintenance Rules (Normative)

*   Idempotence: same memory state and same request should converge to same analysis intent.
*   Change drivers: update analysis when scope changes, new evidence appears, or risk state changes.
*   Closure: once a request is closed in `requests_register.md`, analysis remains unchanged except factual corrections.

## 11. Formatting Requirements

*   All headings must use `##` or `###` consistent with this convention.
*   Bullet lists must use `- `.
*   Tables must use standard GitHub Markdown table syntax.
*   No HTML is allowed.
*   No images, diagrams, embeds, or external hyperlinks.
*   The document must be deterministic (same inputs -> same output intent).
*   Separate chapters, bullets with empty lines for readability

***

## 12. Determinism Rules (Normative)

*   Given the same memory state and request input, analysis output intent must be identical.
*   AI must not guess beyond request scope.
*   If request ambiguity exists that cannot be resolved internally, create a `Q<nnn>` question block in `request.md` -> `## Questions & Decisions` instead of making assumptions.

***

## 13. Prohibited Content

*   Secrets, private keys, credentials, tokens, or sensitive PII.
*   External hyperlinks.
*   Embedded images or diagrams.
*   In-file version/author/status metadata headers.

***


