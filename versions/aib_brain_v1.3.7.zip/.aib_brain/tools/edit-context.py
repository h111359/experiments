"""
edit-context.py: CRUD operations for atomic statements in .aib_memory/context.md.
Part of the AIB tools suite.
Responsibilities: Select, insert, and delete atomic statements by area+type+hash index.
"""

import argparse
import hashlib
import re
import sys
from pathlib import Path

# Ordered list of subsection definitions (prefix, heading text)
SUBSECTIONS = [
    ("PO", "### 2.1 Project overview - PO"),
    ("CM", "### 2.2 Change Management - CM"),
    ("DO", "### 2.3 Domain - DO"),
    ("CO", "### 2.4 Concepts - CO"),
    ("BP", "### 2.5 Best Practices - BP"),
    ("FN", "### 2.6 Functionality - FN"),
    ("TD", "### 2.7 Technical Design - TD"),
    ("TS", "### 2.8 Technology Stack - TS"),
    ("NW", "### 2.9 Networking and Connectivity - NW"),
    ("DS", "### 2.10 Data structures - DS"),
    ("DF", "### 2.11 Data flow - DF"),
    ("PR", "### 2.12 Processes - PR"),
    ("AN", "### 2.13 Analytics - AN"),
    ("UI", "### 2.14 User Interface - UI"),
    ("SC", "### 2.15 Security - SC"),
    ("PF", "### 2.16 Performance - PF"),
    ("OP", "### 2.17 Operations - OP"),
    ("DV", "### 2.18 Development - DV"),
    ("DP", "### 2.19 Deployment - DP"),
    ("DR", "### 2.20 Durability - DR"),
    ("OB", "### 2.21 Observability - OB"),
    ("DM", "### 2.22 Documentation - DM"),
]

# Valid statement type letters
VALID_TYPES = {"N", "R", "C", "E", "L", "U", "A", "D", "I"}

# Pattern matching an atomic statement line
STATEMENT_PATTERN = re.compile(
    r"^- ([A-Z]{2})-([A-Z])-([0-9a-f]{8}): (.+)$"
)


def _build_index(line: str) -> str | None:
    """
    Extract the area+type+hash index from a statement line.

    Args:
        line: A single line from context.md.

    Returns:
        The index string (e.g. 'PO-N-a1b2c3d4') if the line matches, else None.
    """
    match = STATEMENT_PATTERN.match(line.rstrip())
    if match:
        return f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
    return None


def _find_subsection_range(lines: list[str], area: str) -> tuple[int, int]:
    """
    Find the start and end line indices for a given area subsection.

    Args:
        lines: All lines of context.md.
        area: The two-letter area prefix (e.g. 'PO').

    Returns:
        Tuple (start, end) where start is the heading line index and end is the
        line index of the next heading or end of file. Returns (-1, -1) if not found.
    """
    target_heading = None
    for prefix, heading in SUBSECTIONS:
        if prefix == area:
            target_heading = heading
            break

    if target_heading is None:
        return (-1, -1)

    start = -1
    for i, line in enumerate(lines):
        if line.rstrip() == target_heading:
            start = i
            break

    if start == -1:
        return (-1, -1)

    # Find end: next heading at same or higher level, or end of file
    end = len(lines)
    for i in range(start + 1, len(lines)):
        stripped = lines[i].rstrip()
        if stripped.startswith("### ") or stripped.startswith("## "):
            end = i
            break

    return (start, end)


def _find_statements_section(lines: list[str]) -> int:
    """
    Find the line index of the '## 2. Statements' heading.

    Args:
        lines: All lines of context.md.

    Returns:
        Line index of the section heading, or -1 if not found.
    """
    for i, line in enumerate(lines):
        if line.rstrip() == "## 2. Statements":
            return i
    return -1


def _insert_subsection(lines: list[str], area: str) -> list[str]:
    """
    Insert a missing subsection heading in the correct order within ## 2. Statements.

    Args:
        lines: All lines of context.md.
        area: The two-letter area prefix to insert.

    Returns:
        Modified lines with the new subsection heading inserted.
    """
    statements_idx = _find_statements_section(lines)
    if statements_idx == -1:
        sys.stderr.write("Error: '## 2. Statements' section not found in context.md.\n")
        sys.exit(1)

    # Determine target heading and its position in the ordered list
    target_heading = None
    target_order = -1
    for idx, (prefix, heading) in enumerate(SUBSECTIONS):
        if prefix == area:
            target_heading = heading
            target_order = idx
            break

    if target_heading is None:
        sys.stderr.write(f"Error: Unknown area prefix '{area}'.\n")
        sys.exit(1)

    # Find insertion point: after the last subsection heading that precedes this one
    insert_at = statements_idx + 1
    for i in range(statements_idx + 1, len(lines)):
        stripped = lines[i].rstrip()
        # Stop at the next ## level heading (end of Statements section)
        if stripped.startswith("## ") and stripped != "## 2. Statements":
            insert_at = i
            break
        # Check if this is a subsection heading that should come before target
        for order_idx, (prefix, heading) in enumerate(SUBSECTIONS):
            if stripped == heading and order_idx < target_order:
                # Find the end of this subsection content
                insert_at = i + 1
                for j in range(i + 1, len(lines)):
                    if lines[j].rstrip().startswith("### ") or lines[j].rstrip().startswith("## "):
                        insert_at = j
                        break
                    insert_at = j + 1
                break

    # Insert the heading with surrounding blank lines
    new_lines = lines[:insert_at]
    if insert_at > 0 and lines[insert_at - 1].strip() != "":
        new_lines.append("\n")
    new_lines.append(f"{target_heading}\n")
    new_lines.append("\n")
    new_lines.extend(lines[insert_at:])

    return new_lines


def _validate_uniqueness(lines: list[str], exclude_index: str | None = None) -> bool:
    """
    Validate that all statement indices in the file are unique.

    Args:
        lines: All lines of context.md.
        exclude_index: An index to exclude from duplicate checking (for delete ops).

    Returns:
        True if all indices are unique, False otherwise.
    """
    seen: set[str] = set()
    for line in lines:
        idx = _build_index(line)
        if idx is not None and idx != exclude_index:
            if idx in seen:
                sys.stderr.write(f"Error: Duplicate index '{idx}' found in context.md.\n")
                return False
            seen.add(idx)
    return True


def operation_select(lines: list[str], area: str, type_letter: str, hash_val: str) -> int:
    """
    Find and print the statement text matching the given index.

    Args:
        lines: All lines of context.md.
        area: Two-letter area prefix.
        type_letter: Single letter statement type.
        hash_val: 8-character hex hash.

    Returns:
        0 if found, 1 if not found.
    """
    target_index = f"{area}-{type_letter}-{hash_val}"
    for line in lines:
        idx = _build_index(line)
        if idx == target_index:
            match = STATEMENT_PATTERN.match(line.rstrip())
            if match:
                print(match.group(4))
                return 0
    sys.stderr.write(f"Error: Statement with index '{target_index}' not found.\n")
    return 1


def operation_insert(
    lines: list[str],
    area: str,
    type_letter: str,
    hash_val: str,
    text: str,
    related: str | None,
) -> tuple[list[str], int]:
    """
    Insert a new atomic statement in the appropriate subsection.

    Args:
        lines: All lines of context.md.
        area: Two-letter area prefix.
        type_letter: Single letter statement type.
        hash_val: 8-character hex hash.
        text: Statement text content.
        related: Optional comma-separated related identifiers.

    Returns:
        Tuple of (modified lines, exit code). Exit code 0 on success, 1 on failure.
    """
    target_index = f"{area}-{type_letter}-{hash_val}"

    # Check for duplicate index
    for line in lines:
        idx = _build_index(line)
        if idx == target_index:
            sys.stderr.write(
                f"Error: Duplicate index '{target_index}' already exists. Insert rejected.\n"
            )
            return (lines, 1)

    # Find or create the subsection
    start, end = _find_subsection_range(lines, area)
    if start == -1:
        lines = _insert_subsection(lines, area)
        start, end = _find_subsection_range(lines, area)
        if start == -1:
            sys.stderr.write(f"Error: Failed to create subsection for area '{area}'.\n")
            return (lines, 1)

    # Build the statement line
    statement = f"- {area}-{type_letter}-{hash_val}: {text}"
    if related:
        statement += f" {{Related to: {related}}}"
    statement += "\n"

    # Insert at the end of the subsection (before the next heading)
    insert_at = end
    # Skip backwards over trailing blank lines to insert right before them
    while insert_at > start + 1 and lines[insert_at - 1].strip() == "":
        insert_at -= 1

    new_lines = lines[:insert_at]
    new_lines.append(statement)
    new_lines.extend(lines[insert_at:])

    # Post-insert uniqueness validation
    if not _validate_uniqueness(new_lines):
        return (lines, 1)

    return (new_lines, 0)


def operation_delete(lines: list[str], area: str, type_letter: str, hash_val: str) -> tuple[list[str], int]:
    """
    Remove the atomic statement matching the given index.

    Args:
        lines: All lines of context.md.
        area: Two-letter area prefix.
        type_letter: Single letter statement type.
        hash_val: 8-character hex hash.

    Returns:
        Tuple of (modified lines, exit code). Exit code 0 on success, 1 if not found.
    """
    target_index = f"{area}-{type_letter}-{hash_val}"
    found = False
    new_lines: list[str] = []

    for line in lines:
        idx = _build_index(line)
        if idx == target_index:
            found = True
            # Skip this line (delete it)
            continue
        new_lines.append(line)

    if not found:
        sys.stderr.write(f"Error: Statement with index '{target_index}' not found. Nothing deleted.\n")
        return (lines, 1)

    return (new_lines, 0)


def main() -> int:
    """
    Entry point for the edit-context tool.

    Parses arguments and dispatches to the appropriate CRUD operation on
    atomic statements in .aib_memory/context.md.

    Returns:
        0 on success, 1 on error.
    """
    parser = argparse.ArgumentParser(
        description="CRUD operations for atomic statements in .aib_memory/context.md."
    )
    parser.add_argument(
        "--operation",
        required=True,
        choices=["select", "insert", "delete"],
        help="Operation to perform: select, insert, or delete.",
    )
    parser.add_argument(
        "--area",
        required=True,
        help="Two-letter area prefix (e.g. PO, CM, DO).",
    )
    parser.add_argument(
        "--type",
        required=True,
        dest="type_letter",
        help="Single-letter statement type (N, R, C, E, L, U, A, D, I).",
    )
    parser.add_argument(
        "--hash",
        required=True,
        dest="hash_val",
        help="8-character hex hash.",
    )
    parser.add_argument(
        "--text",
        default=None,
        help="Statement text (required for insert).",
    )
    parser.add_argument(
        "--related",
        default=None,
        help="Comma-separated related identifiers (optional, for insert).",
    )
    parser.add_argument(
        "--workspace",
        default=".",
        help="Workspace root path (default: current directory).",
    )

    args = parser.parse_args()

    # Validate area prefix
    valid_areas = {prefix for prefix, _ in SUBSECTIONS}
    if args.area not in valid_areas:
        sys.stderr.write(
            f"Error: Invalid area prefix '{args.area}'. "
            f"Valid prefixes: {', '.join(sorted(valid_areas))}.\n"
        )
        return 1

    # Validate type letter
    if args.type_letter not in VALID_TYPES:
        sys.stderr.write(
            f"Error: Invalid type letter '{args.type_letter}'. "
            f"Valid types: {', '.join(sorted(VALID_TYPES))}.\n"
        )
        return 1

    # Validate hash format
    if not re.match(r"^[0-9a-f]{8}$", args.hash_val):
        sys.stderr.write(
            f"Error: Invalid hash '{args.hash_val}'. Must be exactly 8 lowercase hex characters.\n"
        )
        return 1

    # Validate text is provided for insert
    if args.operation == "insert" and not args.text:
        sys.stderr.write("Error: --text is required for insert operation.\n")
        return 1

    # Locate context.md
    context_path = Path(args.workspace) / ".aib_memory" / "context.md"
    if not context_path.exists():
        sys.stderr.write(f"Error: context.md not found at '{context_path}'.\n")
        return 1

    # Read context.md
    lines = context_path.read_text(encoding="utf-8").splitlines(keepends=True)

    if args.operation == "select":
        return operation_select(lines, args.area, args.type_letter, args.hash_val)

    elif args.operation == "insert":
        new_lines, exit_code = operation_insert(
            lines, args.area, args.type_letter, args.hash_val, args.text, args.related
        )
        if exit_code == 0:
            context_path.write_text("".join(new_lines), encoding="utf-8")
        return exit_code

    elif args.operation == "delete":
        new_lines, exit_code = operation_delete(
            lines, args.area, args.type_letter, args.hash_val
        )
        if exit_code == 0:
            context_path.write_text("".join(new_lines), encoding="utf-8")
        return exit_code

    return 1


if __name__ == "__main__":
    sys.exit(main())
