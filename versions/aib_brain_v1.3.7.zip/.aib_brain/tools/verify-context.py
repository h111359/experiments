"""
verify-context.py: Validate .aib_memory/context.md against context-convention.md rules.
Part of the AIB tools suite.
Responsibilities: Run structural and format checks on context.md, report pass/fail per check,
exit with code 0 if all pass or 1 if any fail.
"""

import argparse
import re
import sys
from pathlib import Path

# Ordered list of expected subsection headings in Section 2
EXPECTED_SUBSECTIONS = [
    "### 2.1 Project overview - PO",
    "### 2.2 Change Management - CM",
    "### 2.3 Domain - DO",
    "### 2.4 Concepts - CO",
    "### 2.5 Best Practices - BP",
    "### 2.6 Functionality - FN",
    "### 2.7 Technical Design - TD",
    "### 2.8 Technology Stack - TS",
    "### 2.9 Networking and Connectivity - NW",
    "### 2.10 Data structures - DS",
    "### 2.11 Data flow - DF",
    "### 2.12 Processes - PR",
    "### 2.13 Analytics - AN",
    "### 2.14 User Interface - UI",
    "### 2.15 Security - SC",
    "### 2.16 Performance - PF",
    "### 2.17 Operations - OP",
    "### 2.18 Development - DV",
    "### 2.19 Deployment - DP",
    "### 2.20 Durability - DR",
    "### 2.21 Observability - OB",
    "### 2.22 Documentation - DM",
]

# Valid two-letter area prefixes extracted from subsection headings
VALID_AREAS = {
    "PO", "CM", "DO", "CO", "BP", "FN", "TD", "TS", "NW",
    "DS", "DF", "PR", "AN", "UI", "SC", "PF", "OP", "DV",
    "DP", "DR", "OB", "DM",
}

# Valid single-letter statement type identifiers
VALID_TYPES = {"N", "R", "C", "E", "L", "U", "A", "D", "I"}

# Pattern matching an atomic statement line
STATEMENT_PATTERN = re.compile(
    r"^- ([A-Z]{2})-([A-Z])-([0-9a-f]{8}): (.+)$"
)

# Pattern matching H2 headings
H2_PATTERN = re.compile(r"^## .+$")

# Pattern matching H3 headings
H3_PATTERN = re.compile(r"^### .+$")

# Pattern detecting HTML tags
HTML_TAG_PATTERN = re.compile(r"<[a-zA-Z/][^>]*>")

# Pattern detecting URLs
URL_PATTERN = re.compile(r"https?://")

# Pattern detecting Markdown table rows (lines starting with |)
TABLE_PATTERN = re.compile(r"^\|")


def _parse_args() -> argparse.Namespace:
    """
    Parse command-line arguments for the verification script.

    Returns:
        Parsed namespace with workspace path.
    """
    parser = argparse.ArgumentParser(
        description="Validate .aib_memory/context.md against context-convention.md rules."
    )
    parser.add_argument(
        "--workspace", default=".", help="Workspace root path (default: current directory)"
    )
    return parser.parse_args()


def _read_context(workspace: Path) -> str:
    """
    Read the context.md file from the workspace.

    Args:
        workspace: Path to workspace root.

    Returns:
        Full text content of context.md.

    Raises:
        FileNotFoundError: If context.md does not exist.
    """
    context_path = workspace / ".aib_memory" / "context.md"
    return context_path.read_text(encoding="utf-8")


def check_preamble(content: str) -> tuple[bool, str]:
    """
    Verify document starts with # Product Context and the auto-generated blockquote preamble.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()
    if not lines or lines[0].strip() != "# Product Context":
        return False, "Document does not start with '# Product Context'."

    # Check for the blockquote preamble within the first 10 lines
    has_blockquote = any(
        line.strip().startswith("> **Auto-generated**") for line in lines[:10]
    )
    if not has_blockquote:
        return False, "Missing auto-generated blockquote preamble in first 10 lines."

    return True, ""


def check_section_structure(content: str) -> tuple[bool, str]:
    """
    Verify exactly three H2 sections exist in order.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    expected = [
        "## 1. Product Identity",
        "## 2. Statements",
        "## 3. Workspace File Inventory",
    ]
    lines = content.splitlines()
    h2_headings = [line.strip() for line in lines if H2_PATTERN.match(line.strip())]

    if h2_headings != expected:
        return False, (
            f"Expected H2 sections {expected}, found {h2_headings}."
        )
    return True, ""


def check_subsection_headings(content: str) -> tuple[bool, str]:
    """
    Verify all 22 subsection headings exist in the correct order under Section 2.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()

    # Find the range between ## 2. Statements and ## 3. Workspace File Inventory
    section2_start = None
    section3_start = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "## 2. Statements":
            section2_start = i
        elif stripped == "## 3. Workspace File Inventory":
            section3_start = i
            break

    if section2_start is None:
        return False, "Section '## 2. Statements' not found."
    if section3_start is None:
        return False, "Section '## 3. Workspace File Inventory' not found."

    # Extract H3 headings in the Statements section
    found_headings = []
    for i in range(section2_start + 1, section3_start):
        stripped = lines[i].strip()
        if H3_PATTERN.match(stripped):
            found_headings.append(stripped)

    if found_headings != EXPECTED_SUBSECTIONS:
        missing = [h for h in EXPECTED_SUBSECTIONS if h not in found_headings]
        extra = [h for h in found_headings if h not in EXPECTED_SUBSECTIONS]
        details = []
        if missing:
            details.append(f"missing: {missing}")
        if extra:
            details.append(f"unexpected: {extra}")
        if not missing and not extra:
            details.append("order mismatch")
        return False, f"Subsection headings issue: {'; '.join(details)}."

    return True, ""


def check_subsection_non_empty(content: str) -> tuple[bool, str]:
    """
    Verify every subsection has at least one atomic statement line.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()

    # Find subsection ranges
    section2_start = None
    section3_start = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "## 2. Statements":
            section2_start = i
        elif stripped == "## 3. Workspace File Inventory":
            section3_start = i
            break

    if section2_start is None or section3_start is None:
        return False, "Cannot locate Section 2 boundaries."

    # Find all subsection heading positions within Section 2
    heading_positions = []
    for i in range(section2_start + 1, section3_start):
        stripped = lines[i].strip()
        if H3_PATTERN.match(stripped) and stripped in EXPECTED_SUBSECTIONS:
            heading_positions.append((i, stripped))

    empty_subsections = []
    for idx, (pos, heading) in enumerate(heading_positions):
        # Determine end of this subsection
        if idx + 1 < len(heading_positions):
            end = heading_positions[idx + 1][0]
        else:
            end = section3_start

        # Check for at least one atomic statement line in this range
        has_statement = False
        for j in range(pos + 1, end):
            if STATEMENT_PATTERN.match(lines[j].strip()):
                has_statement = True
                break

        if not has_statement:
            empty_subsections.append(heading)

    if empty_subsections:
        return False, f"Subsections with no atomic statements: {empty_subsections}."

    return True, ""


def check_statement_format(content: str) -> tuple[bool, str]:
    """
    Verify every bullet line in Section 2 matches the atomic statement pattern.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()

    section2_start = None
    section3_start = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "## 2. Statements":
            section2_start = i
        elif stripped == "## 3. Workspace File Inventory":
            section3_start = i
            break

    if section2_start is None or section3_start is None:
        return False, "Cannot locate Section 2 boundaries."

    invalid_lines = []
    for i in range(section2_start + 1, section3_start):
        stripped = lines[i].strip()
        # Skip empty lines and headings
        if not stripped or H3_PATTERN.match(stripped):
            continue
        # Lines starting with '- ' are statement candidates
        if stripped.startswith("- "):
            match = STATEMENT_PATTERN.match(stripped)
            if not match:
                invalid_lines.append(f"Line {i + 1}: {stripped[:80]}")
            else:
                area, stype, _hash = match.group(1), match.group(2), match.group(3)
                if area not in VALID_AREAS:
                    invalid_lines.append(
                        f"Line {i + 1}: invalid area prefix '{area}'."
                    )
                if stype not in VALID_TYPES:
                    invalid_lines.append(
                        f"Line {i + 1}: invalid type letter '{stype}'."
                    )

    if invalid_lines:
        # Report up to 5 issues to avoid excessive output
        report = invalid_lines[:5]
        suffix = f" (and {len(invalid_lines) - 5} more)" if len(invalid_lines) > 5 else ""
        return False, f"Invalid statement lines: {report}{suffix}."

    return True, ""


def check_statement_uniqueness(content: str) -> tuple[bool, str]:
    """
    Verify no duplicate area+type+hash indices exist in Section 2.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()

    section2_start = None
    section3_start = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "## 2. Statements":
            section2_start = i
        elif stripped == "## 3. Workspace File Inventory":
            section3_start = i
            break

    if section2_start is None or section3_start is None:
        return False, "Cannot locate Section 2 boundaries."

    seen_indices: dict[str, int] = {}
    duplicates = []
    for i in range(section2_start + 1, section3_start):
        match = STATEMENT_PATTERN.match(lines[i].strip())
        if match:
            index = f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
            if index in seen_indices:
                duplicates.append(
                    f"'{index}' on lines {seen_indices[index]} and {i + 1}"
                )
            else:
                seen_indices[index] = i + 1

    if duplicates:
        return False, f"Duplicate indices: {duplicates[:5]}."

    return True, ""


def check_no_external_hyperlinks(content: str) -> tuple[bool, str]:
    """
    Verify no http:// or https:// strings appear in the file.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()
    offending = []
    for i, line in enumerate(lines):
        if URL_PATTERN.search(line):
            offending.append(i + 1)

    if offending:
        return False, f"External URLs found on lines: {offending[:5]}."

    return True, ""


def check_no_html_tags(content: str) -> tuple[bool, str]:
    """
    Verify no HTML tags appear in the file, excluding template placeholders in backticks.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()
    # Pattern to strip inline code spans before checking for HTML
    inline_code_pattern = re.compile(r"`[^`]+`")
    offending = []
    for i, line in enumerate(lines):
        # Remove inline code spans to avoid false positives from placeholders
        cleaned = inline_code_pattern.sub("", line)
        if HTML_TAG_PATTERN.search(cleaned):
            offending.append(i + 1)

    if offending:
        return False, f"HTML tags found on lines: {offending[:5]}."

    return True, ""


def check_no_tables(content: str) -> tuple[bool, str]:
    """
    Verify no Markdown table syntax appears in the file.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()
    offending = []
    for i, line in enumerate(lines):
        if TABLE_PATTERN.match(line.strip()):
            offending.append(i + 1)

    if offending:
        return False, f"Table syntax (|) found on lines: {offending[:5]}."

    return True, ""


def check_inventory_present(content: str) -> tuple[bool, str]:
    """
    Verify Section 3 (Workspace File Inventory) has at least one bullet entry.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()

    section3_start = None
    for i, line in enumerate(lines):
        if line.strip() == "## 3. Workspace File Inventory":
            section3_start = i
            break

    if section3_start is None:
        return False, "Section '## 3. Workspace File Inventory' not found."

    # Look for at least one bullet line after the heading
    for i in range(section3_start + 1, len(lines)):
        stripped = lines[i].strip()
        if stripped.startswith("- "):
            return True, ""
        # Stop if we hit another H2 (shouldn't happen as it's the last section)
        if H2_PATTERN.match(stripped):
            break

    return False, "No bullet entries found in Workspace File Inventory section."


def check_product_identity_non_empty(content: str) -> tuple[bool, str]:
    """
    Verify Section 1 (Product Identity) has substantive prose content.

    Args:
        content: Full text of context.md.

    Returns:
        Tuple of (passed, message).
    """
    lines = content.splitlines()

    section1_start = None
    section2_start = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "## 1. Product Identity":
            section1_start = i
        elif stripped == "## 2. Statements":
            section2_start = i
            break

    if section1_start is None:
        return False, "Section '## 1. Product Identity' not found."
    if section2_start is None:
        return False, "Section '## 2. Statements' not found."

    # Count non-empty, non-heading lines in Product Identity
    content_lines = 0
    for i in range(section1_start + 1, section2_start):
        stripped = lines[i].strip()
        if stripped and not stripped.startswith("#"):
            content_lines += 1

    # Require at least 3 lines of substantive content
    MIN_CONTENT_LINES = 3
    if content_lines < MIN_CONTENT_LINES:
        return False, (
            f"Product Identity has only {content_lines} content lines "
            f"(minimum {MIN_CONTENT_LINES} required)."
        )

    return True, ""


# All checks in execution order
ALL_CHECKS = [
    ("check_preamble", check_preamble),
    ("check_section_structure", check_section_structure),
    ("check_subsection_headings", check_subsection_headings),
    ("check_subsection_non_empty", check_subsection_non_empty),
    ("check_statement_format", check_statement_format),
    ("check_statement_uniqueness", check_statement_uniqueness),
    ("check_no_external_hyperlinks", check_no_external_hyperlinks),
    ("check_no_html_tags", check_no_html_tags),
    ("check_no_tables", check_no_tables),
    ("check_inventory_present", check_inventory_present),
    ("check_product_identity_non_empty", check_product_identity_non_empty),
]


def main() -> int:
    """
    Entry point for the context.md verification tool.

    Runs all checks sequentially, prints structured results, and returns
    exit code 0 if all pass or 1 if any fail.

    Returns:
        0 on all checks passing, 1 on any failure.
    """
    args = _parse_args()
    workspace = Path(args.workspace)

    try:
        content = _read_context(workspace)
    except FileNotFoundError:
        print("[FAIL] file_exists: .aib_memory/context.md not found.")
        print("Results: 0/1 checks passed.")
        return 1

    passed = 0
    failed = 0

    for name, check_fn in ALL_CHECKS:
        ok, message = check_fn(content)
        if ok:
            print(f"[OK] {name}")
            passed += 1
        else:
            print(f"[FAIL] {name}: {message}")
            failed += 1

    total = passed + failed
    print(f"Results: {passed}/{total} checks passed.")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
