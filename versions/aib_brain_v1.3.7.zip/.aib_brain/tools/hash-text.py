"""
hash-text.py: Generate an 8-character hex hash from input text using truncated SHA-256.
Part of the AIB tools suite.
Responsibilities: Accept text input, compute SHA-256, output truncated 8-char hex hash.
"""

import hashlib
import sys


def main() -> int:
    """
    Entry point for the hash-text tool.

    Reads a single positional argument (text to hash), computes the
    truncated SHA-256 hash (first 8 hex characters), and prints it to stdout.

    Returns:
        0 on success, 1 on missing argument.
    """
    if len(sys.argv) < 2:
        sys.stderr.write("Usage: python hash-text.py <text>\n")
        sys.stderr.write("  Computes an 8-character truncated SHA-256 hex hash of <text>.\n")
        return 1

    text = sys.argv[1]
    # Compute SHA-256 and truncate to first 8 hex characters
    hash_value = hashlib.sha256(text.encode("utf-8")).hexdigest()[:8]
    print(hash_value)
    return 0


if __name__ == "__main__":
    sys.exit(main())
