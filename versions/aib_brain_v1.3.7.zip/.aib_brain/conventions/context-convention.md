# Convention: context.md

## Purpose

This convention defines the required structure, atomic statement format, formatting rules, and quality gates for `.aib_memory/context.md`. It is the single authoritative source for the structure of `context.md` and MUST be referenced by the `aib-refresh-context.md` prompt.

This convention is product-agnostic and MUST NOT embed assumptions about any specific product's domain taxonomy or folder structure.

## Applicability

This convention applies to every `.aib_memory/context.md` file in every workspace that uses the AIB framework, regardless of product domain, industry, or technology stack.

## Normative Language

The key words MUST, MUST NOT, SHALL, SHOULD, MAY, and OPTIONAL in this document are to be interpreted as described in BCP 14 (RFC 2119 and RFC 8174).

## Document Identity

- **Canonical file path:** `.aib_memory/context.md`
- **Encoding:** UTF-8
- **Format:** Markdown only. No HTML tags, no images, no external hyperlinks.
- **Authoring model:** Generated or modified by the `aib-refresh-context.md` prompt. Also modified by `edit-context.py` for individual statement CRUD operations. Human edits are not expected but possible.
- **Replacement semantics:** Full-file replacement applies during `aib-refresh-context.md` execution. Individual statement operations via `edit-context.py` use targeted line-level insert/delete.

---

## Section Structure

The document MUST contain exactly three top-level sections, in the following order, using the exact headings specified. No section may be omitted; a mandatory section with no available content MUST include a stub notice as defined in the Stub Notice Format section below.

### Mandatory Section Order and Headings

1. `## 1. Product Identity`
2. `## 2. Statements`
3. `## 3. Workspace File Inventory`

---

## Section Content Guidance

### Section 1 — Product Identity

**Purpose:** Establish what the product is — its name, version, primary purpose, and intended audience.

**MUST include:**
- Product name and version (or version range if relevant).
- One-paragraph purpose statement that a new team member can read and immediately understand what the product does.
- Primary actors or users.
- Production or operational status (e.g., active, deprecated, experimental).

**SHOULD include:**
- Key business outcome the product enables.
- Scope boundaries — what the product is NOT responsible for.

**MUST NOT include:**
- Technical implementation details (those belong in Statements subsections TD or TS).
- Marketing copy or aspirational language without factual basis.

**Format:** Free-form prose (not atomic statements). This section retains its current readable format.

---

### Section 2 — Statements

**Purpose:** Capture all product knowledge as atomic, individually addressable statements organized by area.

This section MUST contain subsections in the exact order listed below. Each subsection groups statements of a specific knowledge area. Empty subsections MAY be omitted only during generation; once a statement exists in a subsection, the heading MUST be present.

#### Subsection Headings (Mandatory Order)

- `### 2.1 Project overview - PO`
- `### 2.2 Change Management - CM`
- `### 2.3 Domain - DO`
- `### 2.4 Concepts - CO`
- `### 2.5 Best Practices - BP`
- `### 2.6 Functionality - FN`
- `### 2.7 Technical Design - TD`
- `### 2.8 Technology Stack - TS`
- `### 2.9 Networking and Connectivity - NW`
- `### 2.10 Data structures - DS`
- `### 2.11 Data flow - DF`
- `### 2.12 Processes - PR`
- `### 2.13 Analytics - AN`
- `### 2.14 User Interface - UI`
- `### 2.15 Security - SC`
- `### 2.16 Performance - PF`
- `### 2.17 Operations - OP`
- `### 2.18 Development - DV`
- `### 2.19 Deployment - DP`
- `### 2.20 Durability - DR`
- `### 2.21 Observability - OB`
- `### 2.22 Documentation - DM`

#### Atomic Statement Format

Each statement is a single Markdown bullet line with the following structure:

```
- <AREA>-<TYPE>-<HASH>: <text> {Related to: <id1>, <id2>}
```

Where:
- `<AREA>` — Two-letter area prefix from the subsection heading (e.g., `PO`, `CM`, `FN`).
- `<TYPE>` — Single-letter statement type identifier (see Statement Types below).
- `<HASH>` — Exactly 8 lowercase hexadecimal characters, computed as `hashlib.sha256(text.encode('utf-8')).hexdigest()[:8]` where `text` is the statement text (excluding the index prefix and relationship suffix).
- `<text>` — The statement content. MUST be a single grammatically complete sentence ending with a period.
- `{Related to: <id1>, <id2>}` — Optional relationship suffix linking to other statement indices.

**Example:**

```
- FN-R-8a86981d: The system must download only files that are new.
- TD-D-3f2a7c01: AIB uses flat Markdown files instead of a database for maximum portability. {Related to: PO-N-b12e4a09}
```

#### Statement Types

| Letter | Type | Description |
|--------|------|-------------|
| N | Definition | Defines a concept, entity, or term. |
| R | Requirement | A functional or non-functional requirement. |
| C | Constraint | A limitation or boundary condition. |
| E | Reference | Points to an external resource or artifact. |
| L | Relationship | Describes a connection between entities. |
| U | Rule | A business or technical rule. |
| A | Assumption | Something assumed to be true. |
| D | Decision | An architectural or design decision. |
| I | Information | General factual information. |

#### Uniqueness Invariant (Normative)

The combination of `<AREA>-<TYPE>-<HASH>` (the statement index) MUST be unique within the entire `context.md` file. Duplicate indices are PROHIBITED. The `edit-context.py` tool validates this invariant on every insert operation.

#### Granularity Principle

Complex or compound statements MUST be split into multiple smaller atomic statements rather than combined into a single long entry. Each statement SHOULD express exactly one fact, requirement, constraint, or decision.

#### Completeness Principle

Statements MUST be detailed enough that the full workspace context can be reconstructed from them alone (in combination with Section 1 and Section 3). A competent developer reading only `context.md` must understand what the product does, why key decisions were made, and how the system works.

---

### Section 3 — Workspace File Inventory

**Purpose:** Provide a quick structural reference of all non-excluded workspace files so that agents and developers can navigate the codebase without prior knowledge.

**MUST include:**
- All workspace-relative file paths discovered during supplementary read, sorted ascending.
- An entry for every directory and subdirectory present in the workspace (using a trailing slash, e.g., `scripts/`), sorted ascending alongside file entries.
- Exclusions applied: `.venv/`, `venv/`, `node_modules/`, `__pycache__/`, `.pytest_cache/`, `.mypy_cache/`, `.git/`.
- When a directory contains three or more items that share a repeating naming pattern (e.g., per-request subfolders under `.aib_memory/requests/`, versioned log files under `logs/`, versioned archive files under `versions/`), do NOT list individual items as separate bullets. Instead, provide a single summary bullet for the directory in the format: `- \`path/\` — Contains <N> <type> items following the pattern \`<pattern>\`; individual items are not listed.`

**Format:**
- Present each entry as a Markdown bullet list item: `- \`path\` — description.`
- File entries: `- \`path/to/file.ext\` — One-sentence description of the file's content or purpose.`
- Directory entries: `- \`path/to/dir/\` — One-sentence description of the folder's role in the workspace.`
- All entries (files and directories together) MUST be sorted ascending by path.

**Description quality requirements:**
- Each description MUST be one sentence, representative of the file's content or purpose.
- Descriptions MUST NOT contain secrets, credentials, or PII.
- For repetitive request artifact files (`request.md`, `implementation.md`, `analysis.md` in per-request folders), a formulaic description derived from the request folder slug is acceptable.

**MUST NOT include:**
- Entries for excluded directories or their contents.

---

## Formatting Rules

1. The document MUST be UTF-8 encoded Markdown.
2. The document MUST NOT contain HTML tags.
3. The document MUST NOT contain images.
4. The document MUST NOT contain external hyperlinks. References to external sources MUST be plain text (author, title, year) only. URLs MUST NOT appear in the file.
5. Heading levels MUST follow this hierarchy:
   - `# Product Context` — document title (H1, exactly one, in the preamble).
   - `## 1. Product Identity`, `## 2. Statements`, `## 3. Workspace File Inventory` — top-level sections (H2).
   - `### <Subsection Name>` — subsections within Section 2 (H3).
6. Bold text (`**text**`) MUST be used only for term definitions and critical callouts within Section 1.
7. Atomic statement lines in Section 2 MUST use Markdown bullet syntax (`- `) followed by the statement index and text.
8. File paths and code identifiers MUST be wrapped in backticks.
9. Traceability references MUST be plain text, not hyperlinks.
10. The document MUST begin with the preamble defined below.
11. Markdown tables MUST NOT appear anywhere in the document.
12. Each atomic statement MUST occupy exactly one line (no line wrapping or continuation lines).
13. Heading nesting MUST NOT exceed H3 (`###`) in any section.

---

## Preamble Format (Normative)

The document MUST begin with the following block, with the timestamp placeholder replaced by the actual generation timestamp in local project time:

```
# Product Context

> **Auto-generated** by `aib-refresh-context.md` on <YYYY-MM-DD HH:MM timezone>.
> Framework definition assets (`.aib_brain/`) are excluded by design — see `.aib_brain/` for AIB framework internals.
> This document is a synthesis of product documentation and workspace sources. It is fully replaced on each execution.
```

---

## Non-Applicable Subsection Format (Normative)

When a mandatory subsection in Section 2 has no applicable content or no information has been found yet, the subsection body MUST contain at least one atomic informational statement explaining the situation.

Use the standard atomic statement format with type letter `I` (Information):

```
- <AREA>-I-<HASH>: <explanation>
```

Where `<explanation>` states either:
- Why the area is not applicable to this product (e.g., `AN-I-<HASH>: No analytics requirements or metrics have been identified for this product.`)
- That no information has been found yet (e.g., `PF-I-<HASH>: No performance requirements have been identified; AIB operates as a local file-based tool with no runtime performance constraints.`)

A subsection MUST NOT be omitted from the document. Every subsection MUST have at least one atomic statement.

---

## Quality Gates

A generated `context.md` passes quality review if and only if all of the following are true:

1. **Structure completeness:** All 3 mandatory sections are present with the exact headings specified in this convention (`## 1. Product Identity`, `## 2. Statements`, `## 3. Workspace File Inventory`).
2. **Non-empty populated sections:** Every section for which source content exists has substantive content (not only a stub notice).
3. **Subsection non-empty:** Every subsection in Section 2 contains at least one atomic informational statement. No subsection is empty or uses non-atomic stub formats.
4. **Statement uniqueness:** Every atomic statement index (area+type+hash) in Section 2 is unique across the entire file.
5. **Statement format compliance:** Every statement line in Section 2 matches the pattern `- <AREA>-<TYPE>-<HASH>: <text>` with valid area prefix, type letter, and 8-char hex hash.
6. **Rebuildability:** A competent developer reading only `context.md` can understand: what the product does, why key decisions were made, and how the system works.
7. **No verbatim reproduction:** Statement text MUST summarize and synthesize source material; it MUST NOT reproduce full source documents.
8. **Determinism:** Re-executing the generating prompt with the same workspace state produces semantically equivalent content.
9. **No external hyperlinks:** The file contains no Markdown-formatted or plain-text URLs (no `http://` or `https://` strings).
10. **No `.aib_brain/` content:** The file MUST NOT contain content derived from `.aib_brain/` framework internals.
11. **Workspace inventory present:** Section 3 lists all non-excluded workspace files in the required format.
12. **No structural definitions in prompt:** The generating prompt contains no hardcoded section names, domain mapping tables, or scope summary tables; it references this convention instead.

---

## Relationship to Other Conventions

- This convention governs ONLY `.aib_memory/context.md`.
- It does NOT govern product-doc files under `.aib_memory/docs/` (governed by their respective per-document conventions).
- It does NOT govern any `.aib_brain/` framework files.
- The `aib-refresh-context.md` prompt MUST reference this convention as the sole structural authority for `context.md`.
