# AIB Workspace Guide

AI Builder (AIB) helps you manage development requests through a structured, AI-assisted workflow.

## Prerequisites

- Python 3.10+ in your terminal.
- Terminal open at the repository root.

## Quick Start

Launch the interactive menu:

```bat
.aib_brain\run.bat        # Windows
```
```sh
sh .aib_brain/run.sh      # Linux / macOS
```

The menu shows copy-paste prompt commands for all AIB actions.

## Daily Flow

1. Write your intent into the `## Input` section of `.aib_memory/input.md`.
2. _(Optional)_ Run analysis in AI chat: `Execute .aib_brain/prompts/aib-analysis.md`
3. Run implement in AI chat: `Execute .aib_brain/prompts/aib-implement.md`
   — If no active request exists, the prompt auto-creates one from `input.md` and proceeds.
   — The request is closed automatically when implementation completes.

## Prompt Invocations

```
Execute .aib_brain/prompts/aib-analysis.md
```
```
Execute .aib_brain/prompts/aib-implement.md
```
```
Execute .aib_brain/prompts/aib-context.md
```

## Use Cases

**Full analysis → implement flow**
1. Write request into `input.md → ## Input`.
2. Run `aib-analysis.md` — auto-creates request, generates `analysis.md` and `request.md`.
3. Review `request.md`; adjust if needed.
4. Run `aib-implement.md` — executes scope and closes request automatically.

**Direct implement (no formal analysis)**
1. Write request into `input.md → ## Input`.
2. Run `aib-implement.md` — auto-creates request from input and implements.

**Regenerate workspace context**
- Run `aib-context.md` at any time (no active request required) to refresh `.aib_memory/context.md`.

**"No changes" toggle**
Check `No changes — provide answer only` in `input.md` before running `aib-analysis.md`. The prompt writes only a timestamped `answer-<timestamp>.md` in the request folder and resets `input.md`; no other files are modified.

## Workspace Instructions (`instructions.md`)

`.aib_memory/instructions.md` is a persistent directives file read by every AIB prompt before it executes. Write any workspace-specific rules here — coding conventions, naming rules, always/never behaviors. If absent or empty, all prompts continue normally.

**Do not store secrets, credentials, or PII in this file.**

## Questions and Answers

When `aib-analysis.md` identifies decision points with multiple valid implementation choices where the preferred option has a materially different impact on the codebase, it generates a `## Questions` section in `input.md`.

**How it works:**

1. After analysis runs, open `.aib_memory/input.md`. If any questions were generated, a `## Questions` section will appear at the end of the file.
2. Each question includes:
   - The question text.
   - A `> **Why this matters:**` line explaining the implementation impact.
   - Mutually exclusive options with checkboxes.
   - A `*(recommended)*` marker on the AI's preferred option.
   - A `> Answer:` field for free-text responses.
3. Answer questions by checking `[x]` next to your chosen option, or writing a free-text answer in the `> Answer:` field.
4. If you leave a question unanswered, the `*(recommended)*` option is applied automatically on re-run.
5. Re-run `aib-analysis.md` — the prompt reads your answers, applies them to the relevant `request.md` sections, and clears the `## Questions` section from `input.md`.

**One Q&A cycle:** After all questions are answered and the analysis prompt is re-run, no new questions are generated (all ambiguities are resolved).

**Note:** The `## Questions` section is ephemeral — it is never part of the `input.md` seed template and is fully cleared after each Q&A cycle.

## Request Folder Artifacts

| Artifact | Created by | Description |
| --- | --- | --- |
| `request.md` | `aib-analysis.md` | Request specification (12 mandatory sections). Active copy lives at `.aib_memory/request.md`; moved to request subfolder after implementation. |
| `analysis.md` | `aib-analysis.md` | Reasoning artifact (not read by `implement`). |
| `implementation.md` | `aib-implement.md` | Append-only implementation log. |
| `inputs/input-archive-*.md` | `aib-analysis.md` | Archived `input.md` per analysis run. Never read by prompts after archiving. |
| `UAT_scenarios.md` | `aib-analysis.md` | Manual test scenarios (created when automated assertions are insufficient). |
| `answer-<timestamp>.md` | `aib-analysis.md` | Written when "No changes" toggle is set. |

