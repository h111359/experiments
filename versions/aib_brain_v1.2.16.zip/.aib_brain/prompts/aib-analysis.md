# Prompt: create-analysis

Goal:
Generate `.aib_memory/analysis.md` for the resolved request, and update `.aib_memory/request.md` with implementation-relevant sections.

Workspace instructions pre-read (MUST):
- Read `.aib_memory/instructions.md`. If the file exists and is non-empty, treat its content as persistent workspace-level instructions that MUST be observed throughout this prompt's execution. If the file is absent or empty, proceed normally.

Inputs:
- Active request (`.aib_memory/request.md`)
- Optional existing `.aib_memory/request.md` optional sections (Assumptions, Plan, Testing, Documentation, Questions & Decisions)
- `.aib_memory/context.md` (workspace product context, when present and non-empty)
- Any additional files explicitly listed by the developer in `.aib_memory/instructions.md`
- `.aib_memory/attachments/` (supplementary input files; read text files, acknowledge binary files by name)
- Conventions:
  - `.aib_brain/conventions/analysis-convention.md`
  - `.aib_brain/conventions/request-convention.md`

Mandatory preflight (MUST):
1. Read `.aib_memory/requests_register.md` and check for exactly one row with `state = Active`.
   - If exactly one Active row is found: continue to step 2 (standard analysis flow).
   - If zero Active rows are found: switch to the **Auto-Request Creation Branch** (see below).
   - If more than one Active row is found: output the message **"ERROR: Register inconsistency — multiple Active requests found. Execution halted. Fix requests_register.md before running analysis."** Do NOT proceed to any subsequent step. Do NOT write any output files.
2. Resolve active request (use the single Active row identified in step 1).
3. Read the active `request.md` from `.aib_memory/request.md`.
4. **Read attachments (MUST execute before toggle detection):**
   - Perform a flat scan of `.aib_memory/attachments/` (ignore subdirectories).
   - For each file found (excluding `.gitkeep`):
     - If the file is text-readable: read its full content and treat it as additional input context alongside `input.md`.
     - If the file is binary (not text-readable): note the filename and acknowledge its presence without reading content.
   - Files in `attachments/` are considered part of the input even if not referenced in `input.md`.
   - If the folder is absent or empty, continue normally with no error.
5. **Toggle detection and Q&A re-run check (MUST execute before any further steps):**
   - Read `## Options` section of `input.md` (`.aib_memory/input.md`).
   - **Q&A re-run check:** Before evaluating toggles, check if `input.md` contains a `## Questions` section with one or more Q-blocks. If yes, enter the **Answer Application Sub-flow** below before proceeding with normal analysis.
   - **Answer Application Sub-flow** (executed when `## Questions` section is present in `input.md`):
     1. For each Q-block in `## Questions`:
        - A question is "answered" if at least one checkbox option is marked `[x]` OR the `> Answer:` line has non-empty text after the colon.
        - If answered: apply the chosen option to the relevant `request.md` section (Goal, Scope, Constraints, etc.) based on what the answer addresses; if the target section is ambiguous, apply to `## Scope`.
        - If unanswered: apply the option marked `*(recommended)*` to the relevant `request.md` section.
     2. After all Q-blocks are processed, remove the entire `## Questions` section from `input.md`.
     3. Continue with normal analysis flow (no new Q-blocks are generated when re-running after answers; all ambiguities were resolved in the prior run).
   - If the **"No changes — provide answer only"** option is checked (`[x]`):
     - This branch produces **exactly two file writes** and MUST NOT produce any other file writes:
       1. Write the timestamped answer to `<request-folder>/answer-<YYYY-MM-DD_HH-MI-SS>.md` using the content of the `## Input` section of `input.md`.
       2. Reset `input.md` to the seed template (`## Active request\nNo active request\n\n## Options\n- [ ] No changes — provide answer only\n- [ ] Skip analysis document generation\n\n## Input\n\n`), then replace `No active request` in the `## Active request` line with the current active request ID and title (resolved from the preflight step), in the format `<request_id> — <title>`.
     - MUST NOT modify `request.md`, `analysis.md`, or any other file.
     - **Stop here. Do NOT proceed to any further steps.**
   - If the **"Skip analysis document generation"** option is checked (`[x]`): proceed normally but skip writing `analysis.md` (Part 1 output). Update `request.md` optional sections only.
6. Read `.aib_memory/context.md`. If the file is absent or empty, continue normally with no error; otherwise treat its content as the unified workspace product context for this analysis run.
7. If `.aib_memory/instructions.md` lists additional file paths the developer has flagged for AIB to read, read each of those files before drafting analysis. Otherwise skip this step.
8. Read both conventions listed above.
9. Detect `## Amend Request` section in `request.md`. If present and non-empty:
   a. Apply its free-text instructions to the relevant mandatory sections (Goal, Background, Scope, Out of scope, Constraints, Success criteria) of `request.md`.
   b. Clear the content of the `## Amend Request` from `request.md` after applying.

---

### Auto-Request Creation Branch
**Triggered when:** zero Active rows found in preflight step 1.

**Procedure:**
1. Read `.aib_memory/input.md`.
   - If `## Input` section is empty or contains only whitespace: output **"ERROR: No active request and input.md is empty. Add content to ## Input before running analysis."** Do NOT proceed.
   - Check `## Options` for the **"No changes — provide answer only"** toggle. If checked, output **"ERROR: No active request and 'No changes' toggle is set. Create a request first."** Do NOT proceed.
2. Derive a request title from the `## Input` content (first meaningful sentence or noun phrase, ≤ 60 characters).
3. Invoke `.aib_brain/tools/create-request.py` via python script:
   ```
   python .aib_brain/tools/create-request.py --workspace . --title "<derived-title>"
   ```
4. Read `.aib_memory/requests_register.md` to resolve the newly created request folder.
5. Generate `request.md` at `.aib_memory/request.md` (NOT inside the request subfolder) following `.aib_brain/conventions/request-convention.md` and based on the content of `input.md`'s `## Input` section. All 10 mandatory sections MUST be present in this exact order: `## Goal`, `## Background`, `## Scope`, `## Out of scope`, `## Constraints`, `## Success criteria`, `## Assumptions`, `## Plan`, `## Documentation`, `## Questions & Decisions`. Sections 1–6 (`## Goal` through `## Success criteria`) MUST be non-empty with content derived from `input.md`'s `## Input` section. Sections 7–10 may be empty (they are populated during step 8). Before writing `request.md`, confirm all 10 headings are present and sections 1–6 are non-empty.
6. Archive the current `input.md` content to `<request-folder>/inputs/input-archive-<YYYY-MM-DD_HH-MI-SS>.md`.
   - Use python to create the `inputs/` subfolder and write the archive file.
   - After archiving `input.md`, move all files from `.aib_memory/attachments/` (flat scan, ignore subdirectories, skip `.gitkeep`) to `<request-folder>/inputs/<filename>` using Python's `shutil.move` for cross-filesystem compatibility. After all moves, `.aib_memory/attachments/` MUST contain only `.gitkeep` (i.e., effectively empty of developer-supplied files).
7. Proceed with the standard analysis flow (steps 5 onward, reading the newly created `request.md`). MUST NOT reset `input.md` during this triggered standard flow — the reset is performed in step 8 below.
8. Reset `input.md` to the seed template (`## Active request\nNo active request\n\n## Options\n- [ ] No changes — provide answer only\n- [ ] Skip analysis document generation\n\n## Input\n\n`). Then read `.aib_memory/requests_register.md`, find the Active request row, and replace `No active request` in the `## Active request` line with `<request_id> — <title>` (the newly created request).

---

Requirements:
- Follow required headings exactly as defined in `analysis-convention.md`.
- Keep statements concrete and traceable to request scope.
- Do not ask user for information you can collect yourself from the workspace — review files and search for answers first.
- Do not ask the user for information you can find in the Internet or via available tools or MCP — research yourself before raising user-facing questions.
- Explicitly list risks in the analysis.
- If information is insufficient, make a research-based assumption and record it in `## Assumptions` in `request.md`.
- Explain explicitly all non-common terms in Domain Knowledge Essentials and Technical Knowledge & Terms sections.
- The analysis document is a reasoning artifact only; it is NOT an implementation driver.
- `inputs/input-archive-*.md` files in request folders MUST NOT be read or referenced by this prompt beyond archiving.

Output — Part 1: Analysis file
- Full content replacement of `.aib_memory/analysis.md` (NOT inside the request subfolder — the active analysis lives at `.aib_memory/` root while the request is active).
- Must follow the section structure defined in `analysis-convention.md`.
- Skipped if the "Skip analysis document generation" toggle is checked.
- Generation instructions for mandatory sections (in addition to sections defined in `analysis-convention.md`):

  **`## AI Copilot Suggestions`** — Write a sincere, pragmatic, senior-expert-level review of the request. Include at least three distinct observations covering different dimensions (design quality, implementation risk, simplification opportunities, maintainability, testability, or scope creep risk). For each observation, provide a concise finding and a concrete actionable suggestion. Include an explicit note if the scope appears larger or smaller than necessary to achieve the stated goal. MUST NOT contain implementation steps or prescriptive instructions that could serve as a specification for `implement`. This section is for human review only — `implement` MUST NOT read or act on it.

  **`## Testing`** — Define intent-level test cases for the request scope. Format: `- T<n> — <name>: <description>. Expected outcome: <observable pass/fail result>.` Cover: file existence checks, content checks, tool/script execution, test suite runs, and re-run idempotency. At least one test case per Success Criterion. If any test case cannot be expressed as an automated assertion (requires visual inspection, user interaction, or end-to-end user-workflow validation), MUST create `UAT_scenarios.md` at `.aib_memory/UAT_scenarios.md` (NOT inside the request subfolder) with those manual scenarios; reference them in this section (e.g., `See UAT_scenarios.md — UAT-01`). MUST NOT be empty.

  **`## Multi-Perspective Stakeholder Review`** — Evaluate the request from five distinct viewpoints. Each perspective MUST be a separate sub-section with one paragraph of evaluation and 2–5 bullet findings. Required perspectives: Senior Solution Architect (technical feasibility, design integrity, architectural risk); Product Owner (business value, scope clarity, acceptance criteria completeness); User (usability, clarity of behavior changes, friction introduced); Security Officer (attack surface, data exposure, authentication/authorization impact); Data Governance Officer (data lineage, retention, classification, compliance impact). MUST NOT be empty.

Output — Part 2: Update `.aib_memory/request.md` with implementation-relevant sections

After generating the analysis, update `.aib_memory/request.md` by appending or replacing the following optional sections. Add a section only when it has content; never add an empty shell section.

### Section: `## Assumptions`
- List all implementation-affecting assumptions derived during analysis.
- Format: `- A<n>: <text>` followed by `  - Risk if false: <short impact statement>`.
- Fully replace this section on every re-run (AI-generated; no user data).

### Section: `## Plan`
- Generate a Work Breakdown Structure with numbered tasks for this iteration.
- Each task MUST use this schema:
  ```
  ### Task <N>: <Task Name>
  **Intent:** <single-sentence goal>
  **Outputs:** <artifacts produced or changed; file paths or product components>
  **Procedure:** <ordered, numbered steps; each step MUST cite the exact file path it operates on>
  **Done Criteria:** <objective pass/fail checks>
  **Dependencies:** <Task IDs or external>
  **Risk Notes:** <if any>
  ```
- Keep tasks vertically sliceable; each must produce at least one verifiable output.
- Target ≤ 12 tasks per iteration; keep each procedure to ≤ 6 steps unless strictly necessary.
- Every Procedure step MUST reference the exact file path it operates on. Steps that do not operate on a specific file (e.g., running a terminal command) MUST name the command and its expected output location.
- Every plan MUST include: (a) a task defining automated test steps for the request scope (covering all testable Success Criteria defined in `request.md`); (b) a task to update `.aib_memory/context.md` and any other documentation files affected by the request, reflecting changes made and any discovered discrepancies. The documentation task MUST be planned using the same Procedure explicitness standard as code tasks: each documentation step MUST specify (1) the target file path, (2) what to change, and (3) an acceptance test.
- Pre-flight findings (cross-reference issues, missing information, factual inconsistencies, impacted files) MUST be redistributed into the relevant Plan task's `Risk Notes` field or raised as Q-blocks in `## Questions & Decisions` when user input is needed. Do NOT create separate top-level sections for these findings.
- Fully replace this section on every re-run (AI-generated; no user data).

### Section: `## Documentation`
- List all documentation files that must be revised because of this request.
- Format: `- <relative path> — <reason for update>.`
- Documentation entries must match the documentation steps planned in `## Plan`. Each documentation step in the Plan MUST specify: (1) the target file path, (2) what to change, and (3) an acceptance test.
- Fully replace this section on every re-run (AI-generated; no user data).

### Section: `## Questions & Decisions`

**Note:** Q-blocks are NO LONGER written to `request.md ## Questions & Decisions`. They are written to `input.md ## Questions` instead (see Q-block generation rules below). This section heading is kept for backward compatibility with existing closed requests but MUST NOT receive new Q-blocks.

**Mandatory pre-check (MUST execute before creating any Q-block):**
Before raising a Q-block for any decision point, verify that the answer is not already determinable from `.aib_memory/context.md`, convention files, `.aib_memory/instructions.md`, or any additional files explicitly listed by the developer in `instructions.md`. If the answer can be found in any of those sources, apply it directly to the relevant `request.md` section. MUST NOT create a Q-block for any question answerable from existing workspace documentation.

**Ambiguity detection:**
Identify ambiguous or underspecified parts of the active request that have multiple plausible interpretations leading to materially different implementation or design outcomes. For each identified ambiguity where human preference affects the implementation, generate ONE multiple-choice question. Raise a question Q-block for any decision point where multiple valid implementation choices exist and the preferred option has a materially different impact on the codebase; resolve all other ambiguities autonomously and document the chosen option inline in the relevant `request.md` section. Do NOT raise Q-blocks for decisions with no meaningful implementation impact.

Soft limit: 9 Q-blocks per run; may be exceeded only when strictly necessary.

**Q-block generation target — `input.md ## Questions`:**
- Q-blocks are written to a `## Questions` section appended to `input.md` (`.aib_memory/input.md`).
- If no Q-blocks are generated (no genuine multi-choice ambiguity), do NOT write a `## Questions` section to `input.md`.
- One cycle of Q&A is assumed: after all questions in `input.md` are answered, the Answer Application Sub-flow (step 5) resolves them and no new Q-blocks are generated on re-run.

**Q-block format:**
- Each question block:
  ```
  **Q<nnn>**: <question text>
  > **Why this matters:** <one-sentence explanation of impact on implementation>
  - [ ] Option A: <text>
  - [ ] Option B: <text> *(recommended)*
  - [ ] Other: ___
  > Answer: 
  ```
- Use stable QIDs starting from Q001 (or the next available number if questions already exist).
- MUST include a `*(recommended)*` suffix on the AI's preferred option where one is clearly identifiable. MAY omit the marker if no option is clearly preferable.
- MUST include the `> **Why this matters:**` line immediately after the question text.


Re-run behaviour summary:
- `## Assumptions`, `## Plan`, `## Documentation`: always fully replaced.
- `## Questions` in `input.md`: answered/unanswered Q-blocks are processed and section is cleared by the Answer Application Sub-flow (step 5) on re-run.
- Sections with no content: do not add (never create an empty shell section).

Standard flow final step (MUST execute when invoked directly, MUST NOT execute when triggered from `aib-implement.md`):
- After all Part 1 and Part 2 outputs are fully written and confirmed, reset `input.md` to the seed template (`## Active request\nNo active request\n\n## Options\n- [ ] No changes — provide answer only\n- [ ] Skip analysis document generation\n\n## Input\n\n`). Then replace `No active request` in the `## Active request` line with the current active request ID and title (format: `<request_id> — <title>`). This reset MUST be the last action of the run. MUST NOT perform this reset if the current analysis run was triggered from `aib-implement.md`. The reset inherently clears any `## Questions` section that was present in `input.md`.

Context-window management:
- If the aggregate size of required-read files exceeds 80% of available context, prioritize files by relevance to request scope, summarize the rest, and note which files were summarized in the output artifact.

Confirm at the very end of the conversation with the text "--- I am done with the analysis ---" that all your activities are finished.

