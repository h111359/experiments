# AIB Workspace Guide

This guide explains how to work with AI Builder (AIB) from the `.aib_brain` folder.

## Purpose

Use AIB tools to manage requests and iterations in a consistent way from the workspace root.

## Prerequisites

- Python 3.10+ available in your terminal.
- Open terminal in the repository root (the folder that contains `.aib_brain`).
- `.aib_brain/tools` scripts available (already part of this repository).

## Quick Start

Run the interactive command menu.

### Windows

```bat
.aib_brain\run.bat
```

### Linux/macOS

```sh
sh .aib_brain/run.sh
```

Menu usage and launch instructions (kept here to avoid wasting menu space):

```text
AI Builder terminal command menu
Launch with .aib_brain/run.bat (Windows) or .aib_brain/run.sh (Linux/macOS).
Use Up/Down arrows + Enter, or press the action number directly.
Press Q to quit from the menu.
```

```text
AI Builder
Command menu for .aib_brain/tools scripts (launchers in .aib_brain)
```

The menu supports:
- Up/Down arrows and Enter
- Numeric shortcuts for actions
- `Q` to quit

## Common Commands

Most users should use the interactive menu above. If needed, you can run tools directly.

### Windows examples

```bat
python .aib_brain\tools\initialize.py --workspace .
python .aib_brain\tools\create-request.py --workspace . --title "My request title"
python .aib_brain\tools\create-iteration.py --workspace . --summary "Follow-up work"
python .aib_brain\tools\close-iteration.py --workspace .
python .aib_brain\tools\close-request.py --workspace .
```

### Linux/macOS examples

```sh
python3 .aib_brain/tools/initialize.py --workspace .
python3 .aib_brain/tools/create-request.py --workspace . --title "My request title"
python3 .aib_brain/tools/create-iteration.py --workspace . --summary "Follow-up work"
python3 .aib_brain/tools/close-iteration.py --workspace .
python3 .aib_brain/tools/close-request.py --workspace .
```

## Typical Daily Flow

1. Initialize once (or when missing state): `initialize.py`
2. Start work: `create-request.py`
3. Add progress steps: `create-iteration.py`
4. Finish current step: `close-iteration.py`
5. Finish whole request: `close-request.py`

## Using `aib-*` Prompts For Iteration Work

Use prompt files in `.aib_brain/prompts/` to generate and execute iteration artifacts for the active request.

Available prompt files:
- `.aib_brain/prompts/aib-analysis.md`
- `.aib_brain/prompts/aib-questionnaire.md`
- `.aib_brain/prompts/aib-plan.md`
- `.aib_brain/prompts/aib-implement.md`
- `.aib_brain/prompts/aib-documentation.md`
- `.aib_brain/prompts/aib-context.md`
- `.aib_brain/prompts/aib-reverse-engineer.md`

Recommended order per iteration:
1. Run `aib-analysis.md` to create `<ITERATION_ID>-analysis.md`.
2. Run `aib-questionnaire.md` if clarification is needed, then answer the generated questionnaire.
3. Run `aib-plan.md` to create a concrete execution plan.
4. Run `aib-implement.md` to execute the change and update `implementation.md`.
5. Run `aib-documentation.md` when documentation updates are in scope.
6. Run `aib-context.md` to regenerate `.aib_memory/context.md` after significant changes.

## How to Run a Prompt in VS Code Chat

1. Ensure you are in a valid AIB state (`initialize` done, active request exists, active iteration exists).
2. Open VS Code Copilot chat.
3. Type or paste the invocation command and send it to the AI agent.
4. Verify the output file is created under `.aib_memory/requests/<request-folder>/` with the current iteration prefix.

### Copy-paste invocations for VS Code chat

```
Execute .aib_brain/prompts/aib-analysis.md
```

```
Execute .aib_brain/prompts/aib-questionnaire.md
```

```
Execute .aib_brain/prompts/aib-plan.md
```

```
Execute .aib_brain/prompts/aib-implement.md
```

```
Execute .aib_brain/prompts/aib-documentation.md
```

```
Execute .aib_brain/prompts/aib-context.md
```

```
Execute .aib_brain/prompts/aib-reverse-engineer.md
```

## Use Case Scenarios

### Scenario 1 — Standard analysis → plan → implement flow

You have a new feature or change request and want to go through the full analysis-plan-implement cycle.

1. Run `create-request.py` (or use the menu) to open a new request.
2. In VS Code chat: `Execute .aib_brain/prompts/aib-analysis.md`
3. In VS Code chat: `Execute .aib_brain/prompts/aib-plan.md`
4. In VS Code chat: `Execute .aib_brain/prompts/aib-implement.md`
5. Run `close-iteration.py` then `close-request.py` when done.

### Scenario 2 — Analysis with open questions and re-iteration

The analysis reveals unknowns that need user input before you can plan.

1. Open a request and run `aib-analysis.md`.
2. The analysis identifies open questions; run `aib-questionnaire.md` to generate a questionnaire.
3. Answer the questionnaire in the generated file.
4. Run `create-iteration.py` to open a new iteration.
5. In the new iteration: run `aib-plan.md` then `aib-implement.md`.
6. Close the iteration and request when done.

### Scenario 3 — Direct implement without a formal plan

The change is small and well-understood; no separate analysis or plan is needed.

1. Open a request.
2. In VS Code chat: `Execute .aib_brain/prompts/aib-implement.md`
3. Close the iteration and request.

### Scenario 4 — Documentation update after code changes

You have already implemented a change and now need to keep product documentation in sync.

1. Open a request describing the documentation update.
2. In VS Code chat: `Execute .aib_brain/prompts/aib-documentation.md`
3. After documentation is updated, optionally run `aib-context.md` to regenerate the unified context.
4. Close the iteration and request.

### Scenario 5 — Regenerate workspace context

You want a fresh, comprehensive summary of the workspace that reflects all recent changes.

1. This prompt can be run standalone without an active request.
2. In VS Code chat: `Execute .aib_brain/prompts/aib-context.md`
3. The file `.aib_memory/context.md` is fully replaced with an up-to-date synthesis.

### Scenario 6 — Reverse-engineer workspace into documentation

You have an existing codebase with no AIB product docs and want to populate them from the workspace.

1. Ensure AIB is initialized (`initialize.py`).
2. Open a request describing the reverse-engineering task.
3. In VS Code chat: `Execute .aib_brain/prompts/aib-reverse-engineer.md`
4. Review and validate the generated documentation under `.aib_memory/docs/`.
5. Close the iteration and request.

## Troubleshooting

- `python` or `python3` not found:
  - Install Python and ensure it is on PATH.
  - On Windows, open a new terminal after installation.
- Permission error when running `run.sh`:
  - Use `sh .aib_brain/run.sh` as shown above.
- Wrong workspace path behavior:
  - Run commands from repository root and keep `--workspace .`.
- Menu starts but action fails:
  - Confirm script exists under `.aib_brain/tools`.
  - Re-run from repository root so relative paths resolve correctly.
- Prompt file not found when executing in VS Code chat:
  - Verify the prompt file name matches one of the 7 files listed in the "Available prompt files" section above.
  - File names changed in v1.0.11: use `aib-analysis.md`, not `aib-create-analysis.md`; use `aib-documentation.md`, not `aib-update-documentation.md`.

## Notes

- This README is updated on explicit request.
- Paths are repository-relative for portability.

## When to Create a New Iteration vs a New Request

Use this decision guide to decide whether your next work unit opens a new **iteration** inside the current request or requires a brand-new **request**.

### Create a new Iteration when

- The goal and scope **have not changed** — you are continuing or extending the work of the active request.
- A prior iteration produced open questions, partial results, or follow-up tasks that are still within the original scope.
- The change is a **refinement, correction, or sub-task** of what was already approved in `request.md`.

**Example:** Iteration 01 produced an analysis with open questions to the user. After the user answers, you open Iteration 02 to create the plan — same goal, different artifact.

### Create a new Request when

- The **goal or scope has fundamentally changed** compared to the current request.
- The work addresses a **different problem, feature, or issue** that is independent of the current request.
- The active request has been **closed** (requests must be Active to receive new iterations).

**Example:** While implementing issue-31, you discover an unrelated bug in another subsystem. Open a new request for the bug rather than extending issue-31's scope.

### Decision checklist

| Question | Yes → | No → |
| --- | --- | --- |
| Is the active request still `Active`? | Consider a new iteration | Must create new request |
| Does this work fall within the original `## Scope` in `request.md`? | New iteration | New request |
| Is this a follow-up to an unresolved item in the latest iteration? | New iteration | New request |
| Is this an independent goal unrelated to the current request? | New request | New iteration |
